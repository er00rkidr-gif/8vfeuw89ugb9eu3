#!/usr/bin/env python3
"""
Generates the Pip skeleton (friendly_pip.geo.json) and every animation (pip.animation.json).

WHY THIS EXISTS
  Pip's body is an OBJ mesh (friendly_pip.obj, measured in blocks). Every OBJ part is attached to a
  GeckoLib bone, and a bone rotates around its *pivot*. The old rig used pivots from a dog skeleton, so
  the arms rotated around a point far away from Pip's shoulders and detached from the body.
  Here every pivot is measured from the actual mesh (px = blocks * 16, left side = +x in geo files,
  GeckoLib mirrors it onto the OBJ's -x side).

USAGE
    python3 tools/build_pip_rig.py          # rewrites the two JSON files
    python3 tools/preview_rig.py            # renders PNG previews of every animation

Rotation cheat-sheet (values in degrees, geo/animation convention):
    arm  rx  negative = swing forward/up      positive = swing backward
    arm  rz  RIGHT arm positive = outward      LEFT arm negative = outward
    head rx  positive = nod down              head rz  positive = tilt to Pip's left
"""
import json
import math
import os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "piphorror")

# ----------------------------------------------------------------------------------------------
# SKELETON (px).  name, parent, pivot
# ----------------------------------------------------------------------------------------------
EYE_L = [1.70, 11.20, -2.35]
EYE_R = [-1.70, 11.20, -2.35]
PUPIL_L = [1.70, 11.20, -3.47]     # centre of the black pupil disc (sits on the front of the eyeball)
PUPIL_R = [-1.70, 11.20, -3.47]

BONES = [
    ("root", None, [0, 0, 0]),
    ("body", "root", [0, 3.7, 0]),            # centre of the round body: lets Pip lie on its side
    ("head", "body", [0, 6.9, 0]),            # neck
    ("mouth", "head", [0, 8.85, -3.0]),
    ("eye_L", "head", EYE_L), ("eyeball_L", "eye_L", EYE_L), ("pupil_L", "eye_L", EYE_L), ("pupil_dot_L", "pupil_L", PUPIL_L), ("eyelid_L", "eye_L", EYE_L),
    ("eye_R", "head", EYE_R), ("eyeball_R", "eye_R", EYE_R), ("pupil_R", "eye_R", EYE_R), ("pupil_dot_R", "pupil_R", PUPIL_R), ("eyelid_R", "eye_R", EYE_R),
    ("arm_L", "body", [3.5, 5.3, 0]),         # shoulder
    ("paw_L", "arm_L", [3.6, 2.5, 0]),        # wrist (paw follows the arm)
    ("arm_R", "body", [-3.5, 5.3, 0]),
    ("paw_R", "arm_R", [-3.6, 2.5, 0]),
]


def build_geo():
    bones = []
    for name, parent, pivot in BONES:
        b = {"name": name, "pivot": pivot}
        if parent:
            b["parent"] = parent
        bones.append(b)
    return {
        "format_version": "1.12.0",
        "minecraft:geometry": [{
            "description": {
                "identifier": "geometry.piphorror.pip",
                "texture_width": 1024,
                "texture_height": 1024,
                "visible_bounds_width": 3,
                "visible_bounds_height": 3,
                "visible_bounds_offset": [0, 0.8, 0],
            },
            "bones": bones,
        }],
    }


# ----------------------------------------------------------------------------------------------
# ANIMATION HELPERS
# ----------------------------------------------------------------------------------------------
def sw(t, length, k=1, ph=0.0):
    """Looping sine: k full cycles per animation, phase in radians."""
    return math.sin(2 * math.pi * k * t / length + ph)


def arm_rot(side, out=0.0, fwd=0.0, twist=0.0):
    """Arm rotation. out = degrees away from the body, fwd = degrees raised forward (negative = back)."""
    rz = -out if side == "L" else out
    return [-fwd, twist, rz]


def sample(fn, length, step):
    n = max(1, int(round(length / step)))
    out = {}
    for i in range(n + 1):
        t = round(min(length, i * step), 4)
        out[("%.3f" % t).rstrip("0").rstrip(".") if t else "0.0"] = [round(v, 3) for v in fn(t)]
    return out


def anim(length, loop, bones, step=0.05):
    """bones: {bone: {channel: fn(t)->[x,y,z]  or  {time:[x,y,z]} dict}}"""
    out = {"loop": loop, "animation_length": length, "bones": {}}
    for bone, chans in bones.items():
        out["bones"][bone] = {}
        for chan, spec in chans.items():
            out["bones"][bone][chan] = spec if isinstance(spec, dict) else sample(spec, length, step)
    return out


def blink(times, closed=0.1, dur=0.14, length=None):
    """Scale keyframes that squash an eye shut briefly."""
    d = {"0.0": [1, 1, 1]}
    for t in times:
        d[str(round(t, 3))] = [1, 1, 1]
        d[str(round(t + dur / 2, 3))] = [1, closed, 1]
        d[str(round(t + dur, 3))] = [1, 1, 1]
    if length is not None:
        d[str(length)] = [1, 1, 1]
    return dict(sorted(d.items(), key=lambda kv: float(kv[0])))


def keyed(points):
    return {str(k): list(v) for k, v in points}


# ----------------------------------------------------------------------------------------------
# ANIMATIONS
# ----------------------------------------------------------------------------------------------
def build_animations():
    A = {}

    # ---- idle: breathing, tiny head sway, arms hang and sway, blink --------------------------
    L = 3.2
    A["animation.pip.idle_stalk"] = anim(L, True, {
        "body": {
            "scale": lambda t: [1 - 0.012 * sw(t, L), 1 + 0.025 * sw(t, L), 1 - 0.012 * sw(t, L)],
            "rotation": lambda t: [0, 0, 1.2 * sw(t, L)],
        },
        "head": {"rotation": lambda t: [2 * sw(t, L, 1, 0.6), 4 * sw(t, L, 1, 1.4), 2.5 * sw(t, L, 1, 2.5)]},
        "arm_L": {"rotation": lambda t: [3 * sw(t, L, 1, 0.3), 0, -(5 + 2 * sw(t, L, 1, 0.8))]},
        "arm_R": {"rotation": lambda t: [-3 * sw(t, L, 1, 0.3), 0, 5 + 2 * sw(t, L, 1, 0.8)]},
        "paw_L": {"rotation": lambda t: [4 * sw(t, L, 1, 1.0), 0, 0]},
        "paw_R": {"rotation": lambda t: [4 * sw(t, L, 1, 1.0 + 0.5), 0, 0]},
        "eye_L": {"scale": blink([2.5], length=L)},
        "eye_R": {"scale": blink([2.5], length=L)},
    })

    # ---- walk: happy waddle-hop (Pip has no legs, so the whole body hops side to side) -------
    L = 0.7
    A["animation.pip.prowl_walk"] = anim(L, True, {
        "body": {
            "position": lambda t: [0, 1.3 * abs(sw(t, L, 1, 0)) * 1.0, 0],
            "rotation": lambda t: [-4, 0, 7 * sw(t, L, 1, 0)],
            "scale": lambda t: [1 + 0.02 * (1 - abs(sw(t, L))), 1 - 0.03 * (1 - abs(sw(t, L))), 1],
        },
        "head": {"rotation": lambda t: [3 * abs(sw(t, L)), 0, -4 * sw(t, L, 1, 0)]},
        "arm_L": {"rotation": lambda t: [-35 * sw(t, L, 1, 0), 0, -(12 + 6 * abs(sw(t, L)))]},
        "arm_R": {"rotation": lambda t: [35 * sw(t, L, 1, 0), 0, 12 + 6 * abs(sw(t, L))]},
        "paw_L": {"rotation": lambda t: [-12 * sw(t, L, 1, 0.6), 0, 0]},
        "paw_R": {"rotation": lambda t: [12 * sw(t, L, 1, 0.6), 0, 0]},
    })

    # ---- listening: arms pop up like perked ears, head tilts toward the speaker --------------
    L = 2.4
    A["animation.pip.lookout_listen"] = anim(L, True, {
        "body": {
            "rotation": lambda t: [-3, 0, 2 * sw(t, L, 1, 0.5)],
            "position": lambda t: [0, 0.4 + 0.3 * sw(t, L, 2, 0), 0],
        },
        "head": {"rotation": lambda t: [-4, 0, 11 + 2 * sw(t, L, 1, 0)]},
        "arm_L": {"rotation": lambda t: arm_rot("L", 118 + 9 * sw(t, L, 2, 0.0), 0)},
        "arm_R": {"rotation": lambda t: arm_rot("R", 118 + 9 * sw(t, L, 2, 1.9), 0)},
        "paw_L": {"rotation": lambda t: [0, 0, 6 * sw(t, L, 2, 0.4)]},
        "paw_R": {"rotation": lambda t: [0, 0, -6 * sw(t, L, 2, 2.3)]},
        "eye_L": {"scale": blink([1.4], length=L)},
        "eye_R": {"scale": blink([1.4], length=L)},
    })

    # ---- peek around a corner: lean out, one paw gripping the edge ---------------------------
    L = 2.2
    A["animation.pip.peek_corner"] = anim(L, True, {
        "body": {
            "rotation": lambda t: [3, 0, -(20 + 3 * sw(t, L, 1, 0))],
            "position": lambda t: [-1.2, 0, 0],
        },
        "head": {"rotation": lambda t: [0, -10 * sw(t, L, 1, 0.4) * 0.5, 22 + 3 * sw(t, L, 2, 0.2)]},
        "arm_L": {"rotation": lambda t: arm_rot("L", 12, 75 + 5 * sw(t, L, 2, 0))},
        "arm_R": {"rotation": lambda t: arm_rot("R", 10, 5)},
        "paw_L": {"rotation": lambda t: [-18 + 6 * sw(t, L, 2, 0.5), 0, 0]},
    })

    # ---- hunt: low pounce-bounce with claws forward ------------------------------------------
    L = 0.5
    A["animation.pip.crawl_hunt"] = anim(L, True, {
        "body": {
            "position": lambda t: [0, 1.6 * abs(sw(t, L, 1, 0)), 0],
            "rotation": lambda t: [18 + 4 * sw(t, L, 2, 0), 0, 3 * sw(t, L, 1, 0)],
            "scale": lambda t: [1 + 0.03 * (1 - abs(sw(t, L))), 1 - 0.05 * (1 - abs(sw(t, L))), 1],
        },
        "head": {"rotation": lambda t: [-14, 0, 0]},
        "arm_L": {"rotation": lambda t: arm_rot("L", 16, 85 + 22 * sw(t, L, 1, 0))},
        "arm_R": {"rotation": lambda t: arm_rot("R", 16, 85 - 22 * sw(t, L, 1, 0))},
        "paw_L": {"rotation": lambda t: [-20 * sw(t, L, 1, 1.2), 0, 0]},
        "paw_R": {"rotation": lambda t: [20 * sw(t, L, 1, 1.2), 0, 0]},
    })

    # ---- fake pip stare: rigid, slightly tilted, arms limp and trembling ----------------------
    L = 2.4
    A["animation.pip.fake_ignore_stare"] = anim(L, True, {
        "body": {"rotation": lambda t: [-2, 0, 0.8 * sw(t, L, 3, 0)]},
        "head": {"rotation": lambda t: [3, 0, -13 + 0.8 * sw(t, L, 5, 0)]},
        "arm_L": {"rotation": lambda t: arm_rot("L", 8 + 0.9 * sw(t, L, 6, 0), 0)},
        "arm_R": {"rotation": lambda t: arm_rot("R", 8 + 0.9 * sw(t, L, 6, 2), 0)},
    })

    # ---- working (chop / fetch): both arms swing down, body bobs ------------------------------
    L = 1.6
    A["animation.pip.event_summon"] = anim(L, False, {
        "body": {
            "position": lambda t: [0, 0.8 * abs(sw(t, L, 2, 0)), 0],
            "rotation": lambda t: [6 + 6 * sw(t, L, 2, math.pi / 2), 0, 0],
        },
        "head": {"rotation": lambda t: [6 + 4 * sw(t, L, 2, math.pi / 2), 0, 0]},
        "arm_L": {"rotation": lambda t: arm_rot("L", 14, 95 - 80 * (0.5 + 0.5 * sw(t, L, 2, -math.pi / 2)))},
        "arm_R": {"rotation": lambda t: arm_rot("R", 14, 95 - 80 * (0.5 + 0.5 * sw(t, L, 2, -math.pi / 2)))},
    })

    # ---- dormant ("Unknown Corpse"): lying on its side, limp, eyes shut -----------------------
    shut = {"0.0": [1, 0.08, 1]}
    A["animation.pip.dormant"] = anim(1.0, True, {
        "body": {
            "rotation": {"0.0": [0, 0, -88], "1.0": [0, 0, -88]},
            "position": {"0.0": [3.4, -0.25, 0], "1.0": [3.4, -0.25, 0]},
        },
        "head": {"rotation": {"0.0": [12, 22, -10], "1.0": [12, 22, -10]}},
        "arm_L": {"rotation": {"0.0": arm_rot("L", 30, 5), "1.0": arm_rot("L", 30, 5)}},
        "arm_R": {"rotation": {"0.0": arm_rot("R", 12, -25), "1.0": arm_rot("R", 12, -25)}},
        "paw_L": {"rotation": {"0.0": [8, 0, 6], "1.0": [8, 0, 6]}},
        "paw_R": {"rotation": {"0.0": [-10, 0, -8], "1.0": [-10, 0, -8]}},
        "eye_L": {"scale": {"0.0": [1, 0.08, 1], "1.0": [1, 0.08, 1]}},
        "eye_R": {"scale": {"0.0": [1, 0.08, 1], "1.0": [1, 0.08, 1]}},
        "pupil_L": {"scale": {"0.0": [0.01, 0.01, 0.01], "1.0": [0.01, 0.01, 0.01]}},
        "pupil_R": {"scale": {"0.0": [0.01, 0.01, 0.01], "1.0": [0.01, 0.01, 0.01]}},
    })

    # ---- wake up: roll upright, eyes pop open, stretch arms, happy hop ------------------------
    L = 2.6
    A["animation.pip.wake_up"] = anim(L, False, {
        "body": {
            "rotation": keyed([(0.0, [0, 0, -88]), (0.5, [0, 0, -88]), (1.1, [0, 0, -30]), (1.45, [0, 0, 8]),
                               (1.75, [0, 0, -4]), (2.1, [0, 0, 0]), (L, [0, 0, 0])]),
            "position": keyed([(0.0, [3.4, -0.25, 0]), (0.5, [3.4, -0.25, 0]), (1.1, [1.2, 0.5, 0]), (1.45, [0, 0, 0]),
                               (1.7, [0, 2.2, 0]), (1.95, [0, 0, 0]), (L, [0, 0, 0])]),
            "scale": keyed([(0.0, [1, 1, 1]), (1.45, [1.04, 0.95, 1.04]), (1.7, [0.97, 1.05, 0.97]),
                            (1.95, [1.04, 0.94, 1.04]), (2.15, [1, 1, 1]), (L, [1, 1, 1])]),
        },
        "head": {"rotation": keyed([(0.0, [12, 22, -10]), (0.6, [12, 22, -10]), (1.2, [-6, 8, 6]),
                                    (1.7, [-8, 0, 0]), (2.2, [0, 0, 0]), (L, [0, 0, 0])])},
        "arm_L": {"rotation": keyed([(0.0, arm_rot("L", 30, 5)), (0.6, arm_rot("L", 30, 5)), (1.4, arm_rot("L", 70, 20)),
                                     (1.75, arm_rot("L", 150, 0)), (2.2, arm_rot("L", 8, 0)), (L, arm_rot("L", 5, 0))])},
        "arm_R": {"rotation": keyed([(0.0, arm_rot("R", 12, -25)), (0.6, arm_rot("R", 12, -25)), (1.4, arm_rot("R", 70, 20)),
                                     (1.75, arm_rot("R", 150, 0)), (2.2, arm_rot("R", 8, 0)), (L, arm_rot("R", 5, 0))])},
        "eye_L": {"scale": keyed([(0.0, [1, 0.08, 1]), (0.7, [1, 0.08, 1]), (0.85, [1, 1.25, 1]), (1.0, [1, 1, 1]),
                                  (L, [1, 1, 1])])},
        "eye_R": {"scale": keyed([(0.0, [1, 0.08, 1]), (0.7, [1, 0.08, 1]), (0.85, [1, 1.25, 1]), (1.0, [1, 1, 1]),
                                  (L, [1, 1, 1])])},
        "pupil_L": {"scale": keyed([(0.0, [0.01] * 3), (0.7, [0.01] * 3), (0.9, [1, 1, 1]), (L, [1, 1, 1])])},
        "pupil_R": {"scale": keyed([(0.0, [0.01] * 3), (0.7, [0.01] * 3), (0.9, [1, 1, 1]), (L, [1, 1, 1])])},
    })

    # ---- talking: mouth flaps + little head bounce (triggered while Pip speaks) ---------------
    def talk(length, flaps):
        def mouth_scale(t):
            open_amt = max(0.0, sw(t, length, flaps, 0)) ** 1.3
            return [1 + 0.1 * open_amt, 1 + 3.2 * open_amt, 1]
        return anim(length, False, {
            "mouth": {"scale": mouth_scale,
                      "position": lambda t: [0, -0.5 * max(0.0, sw(t, length, flaps, 0)) ** 1.3, 0]},
            "head": {"rotation": lambda t: [-2.5 * max(0.0, sw(t, length, flaps, 0)), 0, 2 * sw(t, length, 1, 0)]},
        }, step=0.04)

    A["animation.pip.talk"] = talk(1.4, 5)
    A["animation.pip.talk_long"] = talk(3.2, 12)

    return {"format_version": "1.8.0", "animations": A}


def main():
    geo = build_geo()
    anims = build_animations()
    with open(os.path.join(ROOT, "geo", "friendly_pip.geo.json"), "w") as f:
        json.dump(geo, f, indent=1)
    with open(os.path.join(ROOT, "animations", "pip.animation.json"), "w") as f:
        json.dump(anims, f, separators=(",", ":"))
    print("wrote friendly_pip.geo.json (%d bones) and pip.animation.json (%d animations)" % (len(BONES), len(anims["animations"])))


if __name__ == "__main__":
    main()
