package com.piphorror.mod.storyline;

import com.piphorror.mod.entity.PipChatListener;
import com.piphorror.mod.init.ModEntities;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * "Unknown Corpse" - looks like loot, is actually a sleeping Pip. Hold it and right-click a block to set it
 * down; Pip stays motionless until somebody feeds it a Bucket of Axolotl.
 */
public class UnknownCorpseItem extends Item {
    public UnknownCorpseItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel server)) {
            return InteractionResult.SUCCESS;
        }
        Player player = context.getPlayer();
        BlockPos clicked = context.getClickedPos();
        Direction face = context.getClickedFace();
        BlockState state = level.getBlockState(clicked);
        BlockPos spawnPos = state.getCollisionShape(level, clicked).isEmpty() ? clicked : clicked.relative(face);

        PipChatListener pip = ModEntities.PIP.get().create(server);
        if (pip == null) {
            return InteractionResult.FAIL;
        }
        float yaw = context.getRotation() + 180.0F;
        pip.moveTo(spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D, yaw, 0.0F);
        pip.setYBodyRot(yaw);
        pip.setYHeadRot(yaw);
        pip.setDormant(true);
        if (player != null) {
            pip.setOwner(player);
        }
        if (!level.noCollision(pip)) {
            if (player != null) {
                player.displayClientMessage(Component.literal("§7There isn't enough room to set it down here."), true);
            }
            return InteractionResult.FAIL;
        }

        server.addFreshEntity(pip);
        server.playSound(null, spawnPos, SoundEvents.SLIME_SQUISH_SMALL, SoundSource.NEUTRAL, 1.0F, 0.7F);
        if (player != null) {
            player.displayClientMessage(Component.literal("§7You set it down. Something small and green lies perfectly still..."), true);
            if (!player.getAbilities().instabuild) {
                context.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("item.piphorror.unknown_corpse.tooltip").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("item.piphorror.unknown_corpse.tooltip2").withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
    }
}
