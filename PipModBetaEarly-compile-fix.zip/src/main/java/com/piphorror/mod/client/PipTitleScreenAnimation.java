package com.piphorror.mod.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.piphorror.mod.PipHorrorMod;
import com.piphorror.mod.client.model.PipObjModel;
import net.minecraft.Util;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.client.renderer.LightTexture;
import com.mojang.blaze3d.platform.Lighting;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.Map;

/**
 * Title screen intro. On launch Pip drops in from the top of the screen, lands with a squash,
 * and waves. Later visits to the title screen in the same launch skip the fall.
 *
 * Pip is drawn from the friendly OBJ (the same data the in-world model uses). Only the fall, squash
 * and wave are animated here, so the menu doesn't need GeckoLib.
 */
@Mod.EventBusSubscriber(modid = PipHorrorMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class PipTitleScreenAnimation {
    /** Set to false to turn the intro off. */
    private static final boolean ENABLED = true;

    private static final ResourceLocation TEXTURE =
        new ResourceLocation(PipHorrorMod.MOD_ID, "textures/entity/friendly_pip.png");

    // Timeline in seconds
    private static final float FALL_DELAY = 0.6F;   // let the title screen fade in first
    private static final float FALL_TIME = 0.9F;
    private static final float WAVE_DELAY = 0.4F;   // pause after landing
    private static final float WAVE_TIME = 3.2F;

    /** Pip's total height in blocks, from the geo: head top is about 20/16 of a block. */
    private static final float MODEL_HEIGHT = 1.3F;
    /** Pip's on-screen height as a fraction of the window height. */
    private static final float SCREEN_FRACTION = 0.4F;

    // Pivots from friendly_pip.geo.json, converted from 1/16-block units to blocks.
    // The geo stores the X axis mirrored, so the right limbs (negative X) appear here on the same side.
    private static final float HEAD_PIVOT_Y = 14.0F / 16.0F;
    private static final float SHOULDER_RIGHT_X = -4.2F / 16.0F;
    private static final float SHOULDER_LEFT_X = 4.2F / 16.0F;
    private static final float SHOULDER_Y = 11.4F / 16.0F;

    private static TitleScreen current = null;
    private static long startMs = 0L;
    private static boolean fullIntro = false;
    private static boolean introAlreadyPlayed = false;

    private PipTitleScreenAnimation() {}

    @SubscribeEvent
    public static void onRender(ScreenEvent.Render.Post event) {
        if (!ENABLED || !(event.getScreen() instanceof TitleScreen screen)) {
            return;
        }
        // Parse the mesh before the clock starts, so the first load doesn't skip the animation.
        Map<String, float[]> bones = PipObjModel.getQuadsByBone();
        if (bones == null) {
            return;
        }

        long now = Util.getMillis();
        if (screen != current) {
            current = screen;
            startMs = now;
            fullIntro = !introAlreadyPlayed;
            introAlreadyPlayed = true;
        }
        float t = (now - startMs) / 1000.0F;
        if (!fullIntro) {
            t += FALL_DELAY + FALL_TIME;   // skip straight to landed
        }
        render(event.getGuiGraphics(), screen.width, screen.height, t, bones);
    }

    private static void render(GuiGraphics g, int width, int height, float t, Map<String, float[]> bones) {
        if (t < FALL_DELAY) {
            return;   // still waiting above the screen
        }
        float landT = FALL_DELAY + FALL_TIME;
        float scale = height * SCREEN_FRACTION / MODEL_HEIGHT;     // pixels per block
        float x = width * 0.17F;
        float groundY = height - 14.0F;                            // feet resting point (pixels)
        float startY = -MODEL_HEIGHT * scale;                      // fully above the top of the screen

        // Fall with gravity, then hold on the ground.
        float fall = clamp((t - FALL_DELAY) / FALL_TIME, 0.0F, 1.0F);
        float feetY = lerp(startY, groundY, fall * fall);

        // Squash on landing, then a damped wobble.
        float squash = 0.0F;
        if (t > landT) {
            float s = t - landT;
            squash = (float) (Math.exp(-s * 7.0F) * Math.cos(s * 18.0F));
        }
        float sy = 1.0F - 0.18F * squash;
        float sxz = 1.0F + 0.10F * squash;

        // Tumble while falling, settle when landed.
        float tumble = (1.0F - fall) * 14.0F * (float) Math.sin(t * 7.0F);

        // Arms flail up while falling, then drop to the sides.
        float armRest = 0.0F;
        float armFall = 140.0F + 16.0F * (float) Math.sin(t * 20.0F);
        float arm = t < landT ? armFall : lerp(armFall, armRest, smooth(clamp((t - landT) / 0.3F, 0.0F, 1.0F)));

        // Wave with the right arm (the one on Pip's own right, which is on screen-left when facing the viewer).
        float waveT = t - (landT + WAVE_DELAY);
        float rightArm = arm;
        float headTilt = 0.0F;
        if (waveT > 0.0F && waveT < WAVE_TIME) {
            float up = smooth(clamp(waveT / 0.35F, 0.0F, 1.0F));
            float down = smooth(clamp((WAVE_TIME - waveT) / 0.45F, 0.0F, 1.0F));
            float amount = Math.min(up, down);
            float wave = 135.0F + 22.0F * (float) Math.sin(waveT * 12.0F);
            rightArm = lerp(arm, wave, amount);
            headTilt = 6.0F * amount;
        }
        float idle = t > landT ? (float) Math.sin(t * 2.2F) * 2.0F : 0.0F;
        headTilt += idle;

        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(x, feetY, 200.0F);
        pose.mulPoseMatrix(new Matrix4f().scaling(scale, scale, -scale));
        pose.mulPose(Axis.ZP.rotationDegrees(180.0F));
        pose.mulPose(Axis.ZP.rotationDegrees(tumble));
        pose.scale(sxz, sy, sxz);

        Lighting.setupForEntityInInventory();
        RenderSystem.enableDepthTest();
        VertexConsumer vc = g.bufferSource().getBuffer(RenderType.entityCutoutNoCull(TEXTURE));

        // Everything that isn't animated is drawn as-is.
        for (Map.Entry<String, float[]> e : bones.entrySet()) {
            String name = e.getKey();
            if (isRightArm(name) || isLeftArm(name) || name.equals("head") || name.equals("jaw")
                || name.equals("eyes_glow") || name.equals("ear_left") || name.equals("ear_right")) {
                continue;
            }
            draw(g, vc, e.getValue());
        }

        // Head group: head, jaw, eyes and ears tilt around the neck.
        pose.pushPose();
        pose.translate(0.0F, HEAD_PIVOT_Y, 0.0F);
        pose.mulPose(Axis.ZP.rotationDegrees(headTilt));
        pose.translate(0.0F, -HEAD_PIVOT_Y, 0.0F);
        for (String name : new String[] {"head", "jaw", "eyes_glow", "ear_left", "ear_right"}) {
            draw(g, vc, bones.get(name));
        }
        pose.popPose();

        // Arms rotate around their shoulders. Each arm draws its leg, shin and paw.
        drawArm(g, vc, bones, pose, SHOULDER_RIGHT_X, rightArm, "front_leg_right", "front_shin_right", "front_paw_right");
        drawArm(g, vc, bones, pose, SHOULDER_LEFT_X, -arm, "front_leg_left", "front_shin_left", "front_paw_left");

        g.flush();
        Lighting.setupFor3DItems();
        pose.popPose();
    }

    private static boolean isRightArm(String n) {
        return n.endsWith("_right") && n.startsWith("front_");
    }

    private static boolean isLeftArm(String n) {
        return n.endsWith("_left") && n.startsWith("front_");
    }

    private static void drawArm(GuiGraphics g, VertexConsumer vc, Map<String, float[]> bones, PoseStack pose,
                                float pivotX, float degrees, String upper, String lower, String paw) {
        pose.pushPose();
        pose.translate(pivotX, SHOULDER_Y, 0.0F);
        pose.mulPose(Axis.ZP.rotationDegrees(degrees));
        pose.translate(-pivotX, -SHOULDER_Y, 0.0F);
        draw(g, vc, bones.get(upper));
        draw(g, vc, bones.get(lower));
        draw(g, vc, bones.get(paw));
        pose.popPose();
    }

    private static void draw(GuiGraphics g, VertexConsumer vc, float[] quads) {
        if (quads == null) {
            return;
        }
        PoseStack.Pose pose = g.pose().last();
        Matrix4f matrix = pose.pose();
        Matrix3f normal = pose.normal();
        int stride = PipObjModel.FLOATS_PER_VERTEX;
        for (int i = 0; i + stride <= quads.length; i += stride) {
            vc.vertex(matrix, quads[i], quads[i + 1], quads[i + 2])
                .color(255, 255, 255, 255)
                .uv(quads[i + 3], quads[i + 4])
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT)
                .normal(normal, quads[i + 5], quads[i + 6], quads[i + 7])
                .endVertex();
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static float lerp(float a, float b, float f) {
        return a + (b - a) * f;
    }

    private static float smooth(float f) {
        return f * f * (3.0F - 2.0F * f);
    }
}
